@extends('admin_layout')
@section('admin_content')
<div class="row">
    <div class="col-lg-12">
        <section class="panel">
            <header class="panel-heading">
                Bạn không có đủ quyền để truy cập!!!
            </header>
        </section>
    </div>
</div>
@endsection