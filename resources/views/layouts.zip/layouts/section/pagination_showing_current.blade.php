<div class="pagination-info" aria-label="pagination">
    <div class="pagination-info__text">
        Showing {{ $items->firstItem() }} to {{ $items->lastItem() }} of {{ $items->total() }} entries
    </div>
</div>
